package edu.university.main;

import edu.university.model.Mahasiswa;

public class MainApp {
    public static void main(String[] args) {
        
        Mahasiswa mhs1 = new Mahasiswa("2024001", "Kim Taehyung", 3.75);
        Mahasiswa mhs2 = new Mahasiswa("2024002", "Park Jimin", 3.25);
        Mahasiswa mhs3 = new Mahasiswa("2024003", "Lee Jieun", 2.40);

        
        Mahasiswa[] daftarMahasiswa = {mhs1, mhs2, mhs3};

        System.out.println("========================================");
        System.out.println("         DATA MAHASISWA");
        System.out.println("========================================");

        for (int i = 0; i < daftarMahasiswa.length; i++) {
            System.out.println("Mahasiswa ke-" + (i + 1));
            System.out.println("NIM    : " + daftarMahasiswa[i].getNim());
            System.out.println("Nama   : " + daftarMahasiswa[i].getNama());
            System.out.println("IPK    : " + daftarMahasiswa[i].getIpk());
            System.out.println("Kategori: " + daftarMahasiswa[i].getKategoriIPK());
            System.out.println("----------------------------------------");
        }
    }
}
