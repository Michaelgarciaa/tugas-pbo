package edu.university.staff;

public class MainApp {
    public static void main(String[] args) {
        
        Pegawai[] daftarPegawai = {
            new Dosen("Kim Seokjin", 5000000, 12),
            new Dosen("Park Soeun", 4500000, 10),
            new StafAdministrasi("Lee Minji", 3500000, 20),
            new StafAdministrasi("Choi Yuna", 3000000, 15)
        };

        System.out.println("================================================");
        System.out.println("              DATA PEGAWAI UNIVERSITAS          ");
        System.out.println("================================================");

        for (int i = 0; i < daftarPegawai.length; i++) {
            String jabatan;
            if (daftarPegawai[i] instanceof Dosen) {
                jabatan = "Dosen";
            } else if (daftarPegawai[i] instanceof StafAdministrasi) {
                jabatan = "Staf Administrasi";
            } else {
                jabatan = "Pegawai";
            }

            System.out.println("Pegawai ke-" + (i + 1));
            System.out.println("Nama      : " + daftarPegawai[i].getNama());
            System.out.println("Jabatan   : " + jabatan);
            System.out.printf("Total Gaji: Rp %,.0f%n", daftarPegawai[i].hitungGaji());
            System.out.println("------------------------------------------------");
        }
    }
}
