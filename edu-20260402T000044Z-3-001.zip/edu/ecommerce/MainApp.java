package edu.ecommerce;

public class MainApp {
    public static void main(String[] args) {
        Order order = new Order("ORD-2024001", "Budi");

        Order.OrderItem item1 = order.new OrderItem("Laptop ASUS", 12500000, 1);
        Order.OrderItem item2 = order.new OrderItem("Mouse Logitech", 350000, 2);
        Order.OrderItem item3 = order.new OrderItem("Keyboard Mechanical", 750000, 1);

        Order.OrderItem[] items = {item1, item2, item3};

        order.hitungTotal(items);

        order.tampilkanRincian(items);
    }
}
