package edu.ecommerce;

public class Order {
    private String orderId;
    private String customerName;
    private double total;

    public Order(String orderId, String customerName) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.total = 0;
    }

    public double hitungTotal(OrderItem[] items) {
        total = 0;
        for (int i = 0; i < items.length; i++) {
            total += items[i].getSubtotal();
        }
        return total;
    }

    public void tampilkanRincian(OrderItem[] items) {
        System.out.println("================================================");
        System.out.println("              RINCIAN PESANAN                   ");
        System.out.println("================================================");
        System.out.println("Order ID  : " + orderId);
        System.out.println("Customer  : " + customerName);
        System.out.println("------------------------------------------------");
        System.out.printf("%-20s %10s %5s %12s%n", "Nama Barang", "Harga", "Qty", "Subtotal");
        System.out.println("------------------------------------------------");

        for (int i = 0; i < items.length; i++) {
            System.out.printf("%-20s %,10.0f %5d %,12.0f%n",
                    items[i].getProductName(),
                    items[i].getPrice(),
                    items[i].getQuantity(),
                    items[i].getSubtotal());
        }

        System.out.println("------------------------------------------------");
        System.out.printf("TOTAL KESELURUHAN: Rp %,.0f%n", total);
        System.out.println("================================================");
    }

    public String getOrderId() {
        return orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public double getTotal() {
        return total;
    }

    public class OrderItem {
        private String productName;
        private double price;
        private int quantity;

        public OrderItem(String productName, double price, int quantity) {
            this.productName = productName;
            this.price = price;
            this.quantity = quantity;
        }

        public double getSubtotal() {
            return price * quantity;
        }

        public String getProductName() {
            return productName;
        }

        public double getPrice() {
            return price;
        }

        public int getQuantity() {
            return quantity;
        }
    }
}
