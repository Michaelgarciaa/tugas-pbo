package edu.smartdevice;

public class MainApp {
    public static void main(String[] args) {
        SmartWatch watch = new SmartWatch();

        System.out.println("================================================");
        System.out.println("           SMART WATCH - STATUS DEVICE          ");
        System.out.println("================================================");

        System.out.println("[1] Mengisi baterai selama 45 menit...");
        watch.chargeBattery(45);
        System.out.println("    Baterai saat ini: " + watch.getBatteryLevel() + "%");
        System.out.println("------------------------------------------------");

        System.out.println("[2] Mengisi baterai selama 60 menit...");
        watch.chargeBattery(60);
        System.out.println("    Baterai saat ini: " + watch.getBatteryLevel() + "% (dibatasi maks 100%)");
        System.out.println("------------------------------------------------");

        System.out.println("[3] Menghubungkan ke Wi-Fi...");
        watch.connectWifi("Kampus_Hotspot");
        System.out.println("------------------------------------------------");

        System.out.println("\n================ STATUS AKHIR ==================");
        System.out.println("Baterai    : " + watch.getBatteryLevel() + "%");
        System.out.println("Koneksi    : " + (watch.isConnected() ? "Terhubung" : "Tidak Terhubung"));
        System.out.println("SSID       : " + watch.getSsid());
        System.out.println("================================================");
    }
}
