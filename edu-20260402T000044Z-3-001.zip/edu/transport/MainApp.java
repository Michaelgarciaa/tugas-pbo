package edu.transport;

public class MainApp {
    public static void main(String[] args) {
        double jarak = 120;

        Kendaraan mobil = new Mobil("Toyota Avanza", 150);
        Kendaraan motor = new Motor("Honda Vario", 110);

        double waktuMobil = mobil.hitungWaktuTempuh(jarak);
        double waktuMotor = motor.hitungWaktuTempuh(jarak);

        System.out.println("================================================");
        System.out.println("        PERHITUNGAN WAKTU TEMPUH KENDARAAN      ");
        System.out.println("================================================");
        System.out.println("Jarak Tempuh: " + jarak + " km");
        System.out.println("------------------------------------------------");

        System.out.println("Kendaraan   : " + mobil.getNama());
        System.out.println("Kecepatan Maks: " + mobil.getKecepatanMaks() + " km/jam");
        System.out.println("Kecepatan Efektif (80%): " + (mobil.getKecepatanMaks() * 0.8) + " km/jam");
        System.out.printf("Waktu Tempuh: %.2f jam%n", waktuMobil);
        System.out.println("------------------------------------------------");

        System.out.println("Kendaraan   : " + motor.getNama());
        System.out.println("Kecepatan Maks: " + motor.getKecepatanMaks() + " km/jam");
        System.out.println("Kecepatan Efektif (90%): " + (motor.getKecepatanMaks() * 0.9) + " km/jam");
        System.out.printf("Waktu Tempuh: %.2f jam%n", waktuMotor);
        System.out.println("================================================");
    }
}
